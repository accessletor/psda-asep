NOTE:

By using this font, you are agree to the Product Usage Agreement:

- This font is ONLY for PERSONAL USE. NO COMMERCIAL USE ALLOWED!

- Paypal account for donation: https://paypal.me/aswangga

Any donation are very appreciated

- Purchase full version or COMMERCIAL license: https://salamahtype.com/product/dolphines/

- Explore more amazing fonts visit: https://salamahtype.com

- Follow us on Instagram: @salamahtype

Thank you.


- - - - - - - - - -

INDONESIA:

Dengan menggunakan font ini, anda dianggap menyetujui semua syarat dan ketentuan penggunaan font berikut:

- Dengan lisensi "Personal Use" anda DILARANG KERAS menggunakan font ini untuk kepeluan Komersial yaitu menghasilkan profit/keuntungan melalui Iklan, Percetakan, TV, Film, You-tube, Desain Kemasan Produk (Fisik atau Digital), Distro atau Media apapun.

- Menggunakan Font Lisensi personal untuk kepentingan KOMERSIL tanpa IZIN akan dikenakan denda CORPORATE LICENSE.

- Silakan gunakan lisensi komersial dengan membeli melalui link ini: https://salamahtype.com/product/dolphines/

- Penggunaan Font untuk Perusahaan/Korporasi silakan menggunakan Corporate License.

- Informasi lisensi yang anda butuhkan, silahkan menghubungi kami lewat email: salamahtype@gmail.com atau kontak kami di: https://salamahtype.com

Terima kasih.